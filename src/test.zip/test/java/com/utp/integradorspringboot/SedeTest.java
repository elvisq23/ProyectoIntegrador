package com.utp.integradorspringboot; // EL PAQUETE DE TU CLASE DE PRUEBA (NO SE MODIFICA)

import com.fasterxml.jackson.databind.ObjectMapper;
import com.utp.integradorspringboot.api.SedeRestController; // Importa tu SedeRestController
import com.utp.integradorspringboot.models.Sede;
import com.utp.integradorspringboot.repositories.SedeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// @WebMvcTest(controllers = SedeRestController.class) es la forma más limpia y usual de
// probar un controlador específico. Spring se encargará de encontrarlo y configurar su contexto
// de prueba, incluyendo la inyección de tus @MockBean, sin necesidad de especificar
// scanBasePackages o filtros adicionales, lo que a veces puede causar conflictos.
@WebMvcTest(controllers = SedeRestController.class)
public class SedeTest {

    @Autowired
    private MockMvc simuladorMvc;

    @Autowired
    private ObjectMapper mapeadorObjetos;

    // Este MockBean DEBE ser inyectado en el SedeRestController que MockMvc está probando.
    @MockBean
    private SedeRepository repositorioSede;

    private Sede sedePrincipal;
    private Sede sedeDelNorte;

    @BeforeEach
    void configurar() {
        sedePrincipal = new Sede(1L, "centro", "av. arequipa", "987654321", 100, 50);
        sedeDelNorte = new Sede(2L, "sur", "av. canada", "123456789", 50, 10);

        // ¡Esta configuración es vital para el test de ObtenerSedePorIdEncontrado!
        // Le dice al mock que, cuando se pida el ID 1L, debe devolver sedePrincipal.
        Mockito.when(repositorioSede.findById(1L)).thenReturn(Optional.of(sedePrincipal));
        Mockito.when(repositorioSede.findById(2L)).thenReturn(Optional.of(sedeDelNorte));
        Mockito.when(repositorioSede.findById(anyLong())).thenReturn(Optional.empty()); // Para cualquier otro ID

        // Configuraciones para otros tests (sin cambiar)
        Mockito.when(repositorioSede.findAll()).thenReturn(Arrays.asList(sedePrincipal, sedeDelNorte));
        Mockito.when(repositorioSede.findByNombreSedeContaining("Central")).thenReturn(Arrays.asList(sedePrincipal));
        Mockito.when(repositorioSede.findByNombreSedeContaining(any(String.class))).thenReturn(Collections.emptyList());

        Mockito.when(repositorioSede.save(any(Sede.class))).thenAnswer(invocacion -> {
            Sede sede = invocacion.getArgument(0);
            if (sede.getId() == null) {
                sede.setId(3L);
            }
            return sede;
        });

        Mockito.doNothing().when(repositorioSede).deleteById(1L);

        Mockito.when(repositorioSede.existsById(1L)).thenReturn(true);
        Mockito.when(repositorioSede.existsById(anyLong())).thenReturn(false);
    }

    @Test
    void probarCrearSedeExito() throws Exception {
        Sede nuevaSedePeticion = new Sede("Sede del Sur", "Calle Ficticia 101", "555-1234", 150, 0);

        simuladorMvc.perform(post("/api/sedes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapeadorObjetos.writeValueAsString(nuevaSedePeticion)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.nombreSede").value("Sede del Sur"))
                .andExpect(jsonPath("$.autosOcupados").value(0));
        
        Mockito.verify(repositorioSede, Mockito.times(1)).save(any(Sede.class));
    }

    @Test
    void probarObtenerTodasSedesExito() throws Exception {
        simuladorMvc.perform(get("/api/sedes")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombreSede").value(sedePrincipal.getNombreSede()))
                .andExpect(jsonPath("$[1].nombreSede").value(sedeDelNorte.getNombreSede()))
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void probarObtenerSedePorIdEncontrado() throws Exception {
        // Este test ahora debería funcionar correctamente porque el SedeRestController
        // recibirá el mock configurado para devolver sedePrincipal cuando se le pida 1L.
        simuladorMvc.perform(get("/api/sedes/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(sedePrincipal.getId()))
                .andExpect(jsonPath("$.nombreSede").value(sedePrincipal.getNombreSede()));
    }

    @Test
    void probarActualizarSedeExito() throws Exception {
        Sede sedeParaActualizar = new Sede(1L, "Sede Central Modificada", "Dirección Nueva 123", "999888777", 110, 55);
        
        Mockito.when(repositorioSede.findById(1L)).thenReturn(Optional.of(sedePrincipal)); 
        Mockito.when(repositorioSede.save(any(Sede.class))).thenReturn(sedeParaActualizar); 

        simuladorMvc.perform(put("/api/sedes/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapeadorObjetos.writeValueAsString(sedeParaActualizar)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreSede").value("Sede Central Modificada"))
                .andExpect(jsonPath("$.direccion").value("Dirección Nueva 123"))
                .andExpect(jsonPath("$.autosOcupados").value(55));
        
        Mockito.verify(repositorioSede, Mockito.times(1)).findById(1L);
        Mockito.verify(repositorioSede, Mockito.times(1)).save(any(Sede.class));
    }

    @Test
    void probarEliminarSedeExito() throws Exception {
        Mockito.when(repositorioSede.existsById(1L)).thenReturn(true);
        Mockito.doNothing().when(repositorioSede).deleteById(1L);

        simuladorMvc.perform(delete("/api/sedes/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        Mockito.verify(repositorioSede, Mockito.times(1)).deleteById(1L);
    }
}
